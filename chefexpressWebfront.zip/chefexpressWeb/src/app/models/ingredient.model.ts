export class Ingredient{
    id:number=0
    description:string=""
}