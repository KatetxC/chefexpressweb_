import { Component } from '@angular/core';

@Component({
  selector: 'app-registrarrecipe',
  standalone: true,
  imports: [],
  templateUrl: './registrarrecipe.component.html',
  styleUrl: './registrarrecipe.component.css'
})
export class RegistrarrecipeComponent {

}
